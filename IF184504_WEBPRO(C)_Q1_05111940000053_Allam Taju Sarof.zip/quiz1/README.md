==== index

A
Hello World
Page from Allam

Design System

This page designed using Figma
Coded in VS Code
Uses Bootstrap 5
Inspired by Soft UI and Alto's Adventure
Motivated by Pak Irfan Subakti

create a datatable feature: search + sort(optional)
huhuuu

menu
my 'about me'
my home
blitar's iconic food
blitar's tourist destination

==== about me
Playlist
Hobbies
